{{-- Service Module - Admin Sidebar Menu --}}
{!! admin_menu([
    'title' => 'Services',
    'icon' => 'cog',
    'route' => 'admin.service.index',
    // 'children' => [
    //     ['title' => 'All Services', 'route' => 'admin.service.index', 'icon' => 'list'],
    //     ['title' => 'Add New Service', 'route' => 'admin.service.create', 'icon' => 'plus'],
    // ]
]) !!}
