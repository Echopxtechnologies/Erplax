<?php

use Illuminate\Support\Facades\Route;

// API routes for Service module (if needed)
